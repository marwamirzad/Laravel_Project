<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\user;
use App\project;


class cmsController extends Controller
{
    public function index()
    {
    	if (!Auth::check()) {
 		   return redirect('/login');
 		}
        $user = Auth::user();
        $user_id=$user->id;
    	return view('cms/index',['user'=>$user]);
    	// return view('cms/index');
    }

    public function profile($id)
    {

        if (!Auth::check()) {
           return redirect('/login');
        }
        $user = Auth::user();
        return view('cms/profile',['user'=>$user]);
    }
     public function edit_profile($id)
    {
        if (!Auth::check()) {
           return redirect('/login');
        }
        $user=user::find($id);
        return view('cms/edit_profile',['user'=>$user]);
    }

    public function update_pro(Request $request){
        if (!Auth::check()) {
           return redirect('/login');
        }
        $id=$request->id;
        $pro=user::where("id" ,$id)->get()->first();
        $pro->name=$request->name;
        $pro->last_name=$request->last_name;
        $pro->phone_no=$request->phone_no;
        $pro->email=$request->email_address;
        if ($request->has('photo')) {
            if ($pro->photo!='') {
                $image_path=public_path().'/images/'.$pro->photo;
                unlink($image_path);
            }
            $image=$request->photo;
            $name=rand().'.'.$image->getClientOriginalName();
            $image->move(public_path().'/images/',$name);
            $pro->photo=$name; 
        }
        $pro->instagram=$request->instagram;
        $pro->facebook=$request->facebook;
        $pro->twitter=$request->twitter;
        $pro->position=$request->position;

        $pro->save();
        return redirect('cms')->with('success', 'Successfully updated');
    }
    public function project($value='')
    {
    	if (!Auth::check()) {
           return redirect('/login');
        }
        $data['user'] = Auth::user();
        $project=Project::where("user_id" , $data['user']->id)->get();
        return view('cms/project',['user'=>$data['user'], 'project'=>$project]);
    }
     public function insert_pro(Request $request){
        $user = Auth::user();
        $user_id=$user->id;
        $pro=new Project;
        $pro->user_id=$user_id;
        $pro->name=$request->name;
        $pro->details=$request->details;
        $pro->save();
        return redirect('/project')->with('success','Successfully Inserted');
    }
    public function delete_pro($id){
        $pro=Project::find($id);
        $pro->delete();
        return redirect('/project')->with('success', 'Successfully Deleted');
    }
    public function get_pro_data(){
        $project = Project::where("id" , $_GET['id'])->get()->first();
        return $project;
    }
    public function update_proj(Request $request){
        if (!Auth::check()) {
           return redirect('/login');
        }
        $id=$request->id;
        $pro=Project::where("id" ,$id)->get()->first();
        $pro->name=$request->name;
        $pro->details=$request->details;
        $pro->save();
        return redirect('/project')->with('success', 'Successfully updated');
    }

    public function show_portfolio($id){


        // $id=$request->id;
        // $user = Auth::user();
        // $user_id=$user->id;
        $data['user']=user::where("id" , $id)->get();

        $data['project']=Project::where("user_id" , $id)->get();

        return view('index',$data);        
    }

}
