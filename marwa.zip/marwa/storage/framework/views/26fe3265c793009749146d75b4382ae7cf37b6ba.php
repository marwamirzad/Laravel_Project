<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="fa panel-title">Project list</h3>
                </div>
                    <div class="panel-body">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Add Project +</button>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th class="text-center">#</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Details</th>
                                            <th class="text-center">Date Accompolished</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 1; 
                                        ?>
                                        <?php 
                                            foreach($project as $pro){
                                        ?>
                                        <tr>
                                            <td class="text-center"><?=$i++?></td>
                                            <td class="text-center"><?php echo $pro->name; ?></td>
                                            <td class="text-center"><?php echo e($pro->details); ?></td>
                                            <td class="text-center">
                                                <a href="">
                                                </a>
                                                <a data-toggle="modal" data-target="#category_edit" data-whatever="@getbootstrap" class="project_edit" id="<?php echo e($pro->id); ?>">
                                                    <button type="button" class="btn btn-info btn-info waves-effect m-b-5 ">Edit</button>
                                                </a>
                                                <a href="/cms/project/delete/<?php echo e($pro->id); ?>" onclick="return confirm('Do you want to delete?');">
                                                    <button type="button" class="btn btn-danger waves-effect m-b-5">Delete</button>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                                <!-- <div id="chat-container" class="fixed"></div> -->
                            </div>
                        </div>

                        <!-- Adding new project -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">New Project</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="/insert_pro" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_token()" value="<?php echo e(csrf_token()); ?>">
                                    <div class="form-group">
                                        <label for="recipient-name" class="col-form-label">Name</label>
                                        <input type="text" class="form-control" name="name">
                                    </div>
                                    <div class="form-group">
                                        <label for="recipient-name" class="col-form-label">Details</label>
                                        <textarea class="form-control" name="details"></textarea>
                                    </div>
                                    
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                                </form>
                            </div>
                          </div>
                        </div>

                        <!-- Editing New  -->

                        <div class="modal fade" id="category_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Edit Project</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <form action="/cms/project/update_pro" method="post"  >
                                  <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_token()" value="<?php echo e(csrf_token()); ?>">
                                    <div class="form-group">
                                        <label for="recipient-name" class="col-form-label">Name</label>
                                        <input type="text" id="edit_name" class="form-control" name="name">
                                        <input type="hidden" id="edit_id" name="id">
                                    </div>
                                    <div class="form-group">
                                        <label for="recipient-name" class="col-form-label">Details</label>
                                        <textarea name="details" id="edit_details" class="form-control"></textarea>
                                    </div>
                                   
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                                </form>
                            </div>
                          </div>
                        </div>
                </div>
            </div>
        </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $(".project_edit").click(function(){
                var base_url = '<?php echo url('/') ?>';
                var id = $(this).attr("id");
                $.get(base_url + "/cms/project/getdata" , {id : id} , function(data) {
                    // $("form").attr("action" , '/update');
                    $("#edit_id").val(data.id);
                    $("#edit_name").val(data.name);
                    $("#edit_details").val(data.details);
                });
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>