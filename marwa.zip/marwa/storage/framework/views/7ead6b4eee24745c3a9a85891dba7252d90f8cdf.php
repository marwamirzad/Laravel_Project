<?php $__env->startSection('content'); ?>
    <br>
    <div class="container">
        <form method="POST" action="/update_pro/<?php echo e($user->id); ?>"  enctype="multipart/form-data">
            
            <!-- <?php echo e(method_field('patch')); ?> -->
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="name" class="form-control" autofocus="" tabindex="1" value="<?php echo e($user->name); ?>">
                    </div>
                    <div class="form-group">
                        <label>instagram</label>
                        <input type="text" name="instagram" class="form-control" tabindex="4" value="<?php echo e($user->instagram); ?>">
                    </div>
                    <div class="form-group">
                        <label>Facebook</label>
                        <input type="text" name="facebook" class="form-control" tabindex="7" value="<?php echo e($user->facebook); ?>">
                    </div>
                   
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Last name</label>
                        <input type="text" name="last_name" class="form-control" tabindex="2" value="<?php echo e($user->last_name); ?>">
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" name="email_address" class="form-control" tabindex="5" value="<?php echo e($user->email); ?>">
                    </div>
                      <div class="form-group">
                        <label>Twitter</label>
                        <input type="text" name="twitter" class="form-control" tabindex="10" value="<?php echo e($user->twitter); ?>">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Phone number</label>
                        <input type="number" name="phone_no" class="form-control" tabindex="3" value="<?php echo e($user->phone_no); ?>">
                    </div>
                    <div class="form-group">
                        <label>Photo</label>
                        
                        <img src="<?php echo e(URL::asset('images/' . $user->photo)); ?>" style="width:30px; height: 30px;" alt="No photo">
                        <input type="file" name="photo" class="form-control" tabindex="6" value="<?php echo e($user->photo); ?>">
                    </div>
                    <div class="form-group">
                        <label>Position</label>
                        <input type="text" name="position" class="form-control" tabindex="3" value="<?php echo e($user->position); ?>">
                    </div>
                   
                 
                </div>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-danger" tabindex="11">Save</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>