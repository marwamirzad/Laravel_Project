<?php $__env->startSection('content'); ?> 
    <div class="row" style="padding-top: 30px;">
        <?php //var_dump($user); ?>
        <div class="col-md-1">
            
        </div>
        <div class="col-md-7">
            <table class="table table-striped ">
                <tr class="">
                    <td>Name</td>
                    <td><?php echo e($user->name); ?></td>
                </tr>
                <tr>
                    <td>Last Name</td>
                    <td><?php echo e($user->last_name); ?></td>
                </tr>
                 <tr>
                    <td>Position</td>
                    <td><?php echo e($user->position); ?></td>
                </tr>
                <tr>
                    <td>Phone No</td>
                    <td><?php echo e($user->phone_no); ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><?php echo e($user->email); ?></td>
                </tr>
                <tr>
                    <td>Facebook</td>
                    <td><?php echo e($user->facebook); ?></td>
                </tr>
                <tr>
                    <td>Instagram</td>
                    <td><?php echo e($user->instagram); ?></td>
                </tr>
                <tr>
                    <td>twitter</td>
                    <td><?php echo e($user->twitter); ?></td>
                </tr>
                <tr>
                    <td>Linke of Your Portfolio</td>
                    <td><?php echo url("show_portfolio/".$user->id); ?></td>

                </tr>
            </table>
        </div>
        <div class="col-md-4">
            
        </div>
       <a href="edit_profile/<?php echo e($user->id); ?>">Edit Profile</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>