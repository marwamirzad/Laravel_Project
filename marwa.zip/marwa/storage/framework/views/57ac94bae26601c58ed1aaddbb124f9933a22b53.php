<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta  title="main-page">
  <link rel="stylesheet" type="text/css" href="/assets/personalProfito.css">
</head>
<body>
<nav>
  <ul id='navbar'>
    <li><a href="#welcome-section">About</a></li>
    <li><a href="#projects">Work</a></li>
    <li><a href="#contact">Contact</a></li>
    <li><a href="login.html">Login</a></li>
     <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
  </ul>
  </nav>
  <div id="welcome-section" class="intro">
  <h1>Hey i'am Marwa.</h1>
  <p>a web developer</p>
</div>
<div id="projects" class="work">
	 <h2 class="work-header">These are some of my projects..</h2>
	 <a href="https://codepen.io/marwamirzad/pen/pYyLXb" target="_blank" class="project project-tile">
    <img class="project-pic" src="https://upload.wikimedia.org/wikipedia/commons/e/ed/Elon_Musk_Royal_Society.jpg" alt="project">
    <div class="project-tile">Tribute Page</div>
     </a>
  <a href="https://codepen.io/marwamirzad/pen/OqNZNL" target="_blank" class="project project-tile">
    <img class="project-pic" src="http://www.shreeshardacommunication.com/images/slider/1.jpg" alt="project">
    <div class=" project-tile">Survey Form</div>
  </a>
   <a href="https://codepen.io/marwamirzad/pen/qvmrPO " target="_blank" class="project project-tile">
    <img class="project-pic" src="http://www.geo-viz.com/wp-content/themes/geoviz/js/timthumb.php?src=http://www.geo-viz.com/wp-content/uploads/2015/05/PHP.jpg&h=280&w=600" alt="project">
    <div class=" project-tile">PHP Documentation</div>
  </a>
    <a href="https://codepen.io/marwamirzad/pen/eXWGgJ" target="_blank" class="project project-tile">
    <img class="project-pic" src="https://www.verticalresponse.com/blog/wp-content/uploads/2013/04/Company-Profile.jpg" alt="project">
    <div class=" project-tile">Personal Portfolio Webpage</div>
</div>
<div id="contact" class="contact">
  <div class="header">
    <h1>Let's work together...</h1><br>
  </div>
  <a href="https://facebook.com/freecodecamp" target="_blank" class="contact-info">Facebook</a>
  <a id='profile-link' href="https://github.com/freecodecamp" target="_blank" class="contact-info">Inatagram</a>
  <a href="https://twitter.com/freecodecamp" target="_blank" class="contact-info">Twitter</a>
  <a href="mailto:example@example.com" class="contact-info">Send a mail</a>
  <a href="tel:555-555-5555" class="contact-info">Call me</a>
</div>
<footer>This is my own profile </footer>
</body>
</html>