<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta  title="main-page">
  <link rel="stylesheet" type="text/css" href="/assets/personalProfito.css">
</head>
<body>
<nav>
  <ul id='navbar'>
    <li><a href="#welcome-section">About</a></li>
    <li><a href="#projects">Work</a></li>
    <li><a href="#contact">Contact</a></li>
  </ul>
  </nav>
  <div id="welcome-section" class="intro">
  <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <h1>Hey i'am <?php echo $us->name; ?>.</h1>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <p>a <?php echo $us->position; ?></p>
</div>
<div id="projects" class="work">
	 <h2 class="work-header">These are some of my projects..</h2>
   <?php 
        foreach($project as $pro){
    ?>
    <a href="https://codepen.io/marwamirzad/pen/pYyLXb" target="_blank" class="project project-tile">
    <img class="project-pic" src="/images/pro-img-1.jpg" alt="project">
    <div class="project-tile"><?php echo $pro->name; ?>
     <h4><?php echo $pro->details; ?></h4>
      
    </div>
     </a>

    <?php } ?>
	 
</div>
<div id="contact" class="contact">
  <div class="header">
    <h1>Let's work together...</h1><br>
  </div>
    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo $us->facebook; ?>" target="_blank" class="contact-info">Facebook</a>
      <a id='profile-link' href="<?php echo $us->instagram; ?>" target="_blank" class="contact-info">Inatagram</a>
      <a href="<?php echo $us->twitter; ?>" target="_blank" class="contact-info">Twitter</a>
      <a href="<?php echo $us->email; ?>" class="contact-info">Send a mail</a>
      <a href="<?php echo $us->phone_no; ?>" class="contact-info">Call me</a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<footer>This is my own profile </footer>
</body>
</html>