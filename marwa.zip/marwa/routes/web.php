<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('index','adminController@index');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/cms', 'cmsController@index')->name('cms');
Route::get('/profile', 'cmsController@profile')->name('profile');
Route::get('/profile/{id}','cmsController@profile');

Route::get('/profile/edit_profile/{id}','cmsController@edit_profile');
Route::post('/update_pro/{id}','cmsController@update_pro');

Route::get('/project','cmsController@project')->name('project');
Route::post('/insert_pro','cmsController@insert_pro')->name('insert_pro');
Route::get('/cms/project/getdata','cmsController@get_pro_data');
Route::post('/cms/project/update_pro','cmsController@update_proj');
Route::get('/cms/project/delete/{id}','cmsController@delete_pro');


Route::get('show_portfolio/{id}','cmsController@show_portfolio')->name('show_portfolio');




