@extends('cms.index')
@section('content') 
    <div class="row" style="padding-top: 30px;">
        <?php //var_dump($user); ?>
        <div class="col-md-1">
            
        </div>
        <div class="col-md-7">
            <table class="table table-striped ">
                <tr class="">
                    <td>Name</td>
                    <td>{{$user->name}}</td>
                </tr>
                <tr>
                    <td>Last Name</td>
                    <td>{{$user->last_name}}</td>
                </tr>
                 <tr>
                    <td>Position</td>
                    <td>{{$user->position}}</td>
                </tr>
                <tr>
                    <td>Phone No</td>
                    <td>{{$user->phone_no}}</td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>{{$user->email}}</td>
                </tr>
                <tr>
                    <td>Facebook</td>
                    <td>{{$user->facebook}}</td>
                </tr>
                <tr>
                    <td>Instagram</td>
                    <td>{{$user->instagram}}</td>
                </tr>
                <tr>
                    <td>twitter</td>
                    <td>{{$user->twitter}}</td>
                </tr>
                <tr>
                    <td>Linke of Your Portfolio</td>
                    <td><?php echo url("show_portfolio/".$user->id); ?></td>

                </tr>
            </table>
        </div>
        <div class="col-md-4">
            
        </div>
       <a href="edit_profile/{{$user->id}}">Edit Profile</a>
    </div>
@stop