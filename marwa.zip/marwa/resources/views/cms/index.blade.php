<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="assets/images/favicon_1.ico">

        <title>Admin Panel</title>

        <link rel="stylesheet" type="text/css" href="{{ URL::asset('cms_assets/plugins/sweetalert/dist/sweetalert.css') }}">
        <link href="{{ URL::asset('cms_assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
        <link rel="stylesheet" type="text/css" href="{{ URL::asset('cms_assets/css/icons.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ URL::asset('cms_assets/css/core.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ URL::asset('cms_assets/css/components.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ URL::asset('cms_assets/css/pages.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ URL::asset('cms_assets/css/menu.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ URL::asset('cms_assets/css/responsive.css') }}">
        <script type="text/javascript" src="{{ URL::asset('cms_assets/js/modernizr.min.js') }}"></script>

        <!-- <link href="cms_assets/plugins/sweetalert/dist/sweetalert.css" rel="stylesheet" type="text/css"> -->

        <!-- <link href="cms_assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"> -->
        <!-- <link href="cms_assets/css/core.css" rel="stylesheet" type="text/css"> -->
        <!-- <link href="cms_assets/css/icons.css" rel="stylesheet" type="text/css"> -->
        <!-- <link href="cms_assets/css/components.css" rel="stylesheet" type="text/css"> -->
        <!-- <link href="cms_assets/css/pages.css" rel="stylesheet" type="text/css"> -->
        <!-- <link href="cms_assets/css/menu.css" rel="stylesheet" type="text/css"> -->
        <!-- <link href="cms_assets/css/responsive.css" rel="stylesheet" type="text/css"> -->
        <!-- <script src="cms_assets/js/modernizr.min.js"></script> -->
    </head>

    
    <body class="fixed-left">
        <!-- Begin page -->
        <div id="wrapper">
        
            <!-- Top Bar Start -->
            <div class="topbar">
                <!-- LOGO -->
                <div class="topbar-left" >
                    <div class="text-center">
                        <a href="" class="logo"><i class="md md-terrain"></i> <span>Admin Panle</span></a>
                    </div>
                </div>
                <!-- Button mobile view to collapse sidebar menu -->
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">
                        <div class="">
                            <div class="pull-left">
                                <button class="button-menu-mobile open-left">
                                    <i class="fa fa-bars"></i>
                                </button>
                                <span class="clearfix"></span>

                            </div>
                             <ul class="nav navbar-nav navbar-right pull-right">
                                <li class="hidden-xs">
                                    <a href="" class="waves-effect waves-light">
                                        <?php echo $user->name; ?>   
                                    </a>
                                </li>
                                <li class="hidden-xs">
                                    <a href="#" id="btn-fullscreen" class="waves-effect waves-light"><i class="md md-crop-free"></i></a>
                                </li>
                                
                                <li class="dropdown">
                                    <a href="" class="dropdown-toggle profile" data-toggle="dropdown" aria-expanded="true">
                                        <img src="{{ URL::asset('images/' . $user->photo)}}" style="width:30px; height: 30px;" alt="No photo" class="img-circle">
                                     </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="edit_profile/{{$user->id}}"><i class="md md-face-unlock"></i> Edit Profile</a></li>
                                        
                                        
                                        <li><a class="dropdown-item" href="{{ route('logout') }}"
                                               onclick="event.preventDefault();
                                                             document.getElementById('logout-form').submit();">
                                                             <i class="md md-settings-power"></i>
                                                {{ __('Logout') }}
                                            </a>
                                         <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                                @csrf
                                            </form>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                </div>
            </div>
            <!-- Top Bar End -->
            <!-- ========== Left Sidebar Start ========== -->
            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">
                    <div class="user-details">
                        <div class="pull-left">
                            <img src="{{ URL::asset('images/' . $user->photo)}}" alt="" class="thumb-md img-circle  ">
                        </div>
                        <div class="user-info">
                            <div class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <?php echo $user->name; ?> <span class="caret"></span></a>
                                 <ul class="dropdown-menu">
                                        <li><a href="edit_profile/{{$user->id}}"><i class="md md-face-unlock"></i> Edit Profile</a></li>
                                       
                                        <li><a class="dropdown-item" href="{{ route('logout') }}"
                                               onclick="event.preventDefault();
                                                             document.getElementById('logout-form').submit();">
                                                             <i class="md md-settings-power"></i>
                                                {{ __('Logout') }}
                                            </a>
                                         <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                                @csrf
                                            </form>
                                        </li>
                                    </ul>
                            </div>
                            
                            <p class="text-muted m-0">Administrator</p>
                        </div>
                    </div>
                    <!--- Divider -->
                    <div id="sidebar-menu">
                        <ul>
                            <li>
                                <a href="{{ route('profile') }}/{{$user->id}}" class="waves-effect "><i class="md md-person"></i><span> Profile </span></a>
                            </li>
                       
                             <li>
                                <a href="{{ route('project')}}" class="waves-effect"><i class="md md-book"></i><span> Project </span></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        {{csrf_field()}}
                        @if(session('success'))
                           <div class="alert alert-success">
                                {{ session('success') }}
                           </div> 
                        @endif
                        @yield('content')
                    </div> <!-- container -->           
                </div> <!-- content -->
                <footer class="footer text-right">
                    Admin Panel
                </footer>
            </div>
           
            <!-- ============================================================== -->  

            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->


    
        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src=" {{URL::asset('cms_assets/js/jquery.min.js')}}"></script>
        <script src="{{URL::asset('cms_assets/js/bootstrap.min.js')}} "></script>
        <script src="{{URL::asset('cms_assets/js/detect.js')}}  "></script>
        <script src="{{URL::asset('cms_assets/js/fastclick.js')}}"></script>
        <script src="{{URL::asset('cms_assets/js/jquery.slimscroll.js')}}"></script>
        <script src="{{URL::asset('cms_assets/js/jquery.blockUI.js')}}"></script>
        <script src="{{URL::asset('cms_assets/js/waves.js')}}"></script>
        <script src="{{URL::asset('cms_assets/js/wow.min.js')}}"></script>
        <script src="{{URL::asset('cms_assets/js/jquery.nicescroll.js')}}"></script>
        <script src="{{URL::asset('cms_assets/js/jquery.scrollTo.min.js')}}"></script>

        <script src="{{URL::asset('cms_assets/js/jquery.app.js')}}"></script>
        
        <!-- jQuery  -->
        <script src="{{URL::asset('cms_assets/plugins/moment/moment.js')}}"></script>
        
        <!-- jQuery  -->
        <script src="{{URL::asset('cms_assets/plugins/waypoints/lib/jquery.waypoints.js')}}"></script>
        <script src="{{URL::asset('cms_assets/plugins/counterup/jquery.counterup.min.js')}}"></script>
        
        <!-- jQuery  -->
        <script src="{{URL::asset('cms_assets/plugins/sweetalert/dist/sweetalert.min.js')}}"></script>
        
        
        <!-- flot Chart -->
        <script src="{{URL::asset('cms_assets/plugins/flot-chart/jquery.flot.js')}}"></script>
        <script src="{{URL::asset('cms_assets/plugins/flot-chart/jquery.flot.time.js')}}"></script>
        <script src="{{URL::asset('cms_assets/plugins/flot-chart/jquery.flot.tooltip.min.js')}}"></script>
        <script src="{{URL::asset('cms_assets/plugins/flot-chart/jquery.flot.resize.js')}}"></script>
        <script src="{{URL::asset('cms_assets/plugins/flot-chart/jquery.flot.pie.js')}}"></script>
        <script src="{{URL::asset('cms_assets/plugins/flot-chart/jquery.flot.selection.js')}}"></script>
        <script src="{{URL::asset('cms_assets/plugins/flot-chart/jquery.flot.stack.js')}}"></script>
        <script src="{{URL::asset('cms_assets/plugins/flot-chart/jquery.flot.crosshair.js')}}"></script>

        <!-- jQuery  -->
        <script src="{{URL::asset('cms_assets/pages/jquery.todo.js')}}"></script>
        
        <!-- jQuery  -->
        <script src="{{URL::asset('cms_assets/pages/jquery.chat.js')}}"></script>
        
        <!-- jQuery  -->
        <script src="{{URL::asset('cms_assets/pages/jquery.dashboard.js')}}"></script>
        <script type="text/javascript">
            /* ==============================================
            Counter Up
            =============================================== */
            jQuery(document).ready(function($) {
                $('.counter').counterUp({
                    delay: 100,
                    time: 1200
                });
            });
        </script>
        @yield('scripts')
    </body>
</html>



<!-- Localized -->